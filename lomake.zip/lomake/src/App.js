import React from 'react';
import Form from './Form'; // Oletetaan, että Form-komponentti on samassa hakemistossa

function App() {
  return (
    <div className="App">
      <h1>Lomakkeen Esimerkki</h1>
      <Form />
    </div>
  );
}

export default App;
