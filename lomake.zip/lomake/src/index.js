import React from 'react';
import ReactDOM from 'react-dom';
import App from './App'; // Oletetaan, että App on samassa hakemistossa

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);
